# AMOK SARL

Première base web du projet AMOK SARL — plateforme privée de référencement commercial et de mise en relation au Niger.

## Contenu
- `index.html` : page d'accueil de démonstration, adaptée aux téléphones.

## Important
Cette archive est une base de démarrage visuelle. Elle ne contient pas encore de serveur, de base de données, d'authentification réelle, de paiement mobile ni de publication d'annonces sécurisée. Ces fonctions devront être développées et testées avant toute utilisation réelle.

## Ajouter à GitHub depuis un téléphone
1. Téléchargez puis ouvrez cette archive ZIP sur le téléphone.
2. Extrayez-la (décompressez-la) dans l'application Fichiers.
3. Dans GitHub, ouvrez le dépôt `Amoksarl/Amok-sarl` puis **Ajouter un fichier → Téléverser des fichiers**.
4. Sélectionnez les fichiers extraits `index.html` et `README.md` (pas l'archive ZIP).
5. Validez les modifications avec un message comme `Ajout de la première page AMOK`.
